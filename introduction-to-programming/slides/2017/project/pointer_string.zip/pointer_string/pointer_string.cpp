/*
 * pointer_string.cpp
 *
 *  Created on: 17 Dec 2017
 *      Author: fanj
 */

#include "pointer_string.h"

void ParseLine (char *line, struct Query *ptr) {
	char *start, *end;
	start = end = line;
	int count = 0;
	do {
		if (*end==',' || *end=='\0') {
			char part[100] = "";
			strncpy (part, start, end-start);
			if (count == 0) ParseUID(part, ptr);
			else if (count == 1) ParseText(part, ptr);
			else if (count == 2) ParseDate(part, ptr);
			count ++;
			start = end = end+1;
		} else {
			end++;
		}
	} while (*(end-1) != '\0');
}

void ParseUID (char *part, struct Query *ptr) {
	(*ptr).uid = stoi(part);
}

void ParseText (char *part, struct Query *ptr) {
	strcpy((*ptr).text, part);
	(*ptr).text[strlen(part)] = '\0'; // manually add \0
}

void ParseDate (char *part, struct Query *ptr) {
	char *start, *end;
	start = end = part;
	do {
		if (*end=='/' || *end=='-' ||
				*end=='\0') {
			char str[5] = "";
			strncpy(str,start,end-start);
			if (strlen(str) == 4) {
				(*ptr).year = stoi (str);
			} else {
				(*ptr).month = stoi (str);
			}
			start = end = end+1;
		} else {
			end++;
		}
	}while (*(end-1) != '\0');
}


int SubstrOccurNum(char *str, char *substr) {
	char *p, *q;
	q = substr;
	int sublen = strlen(substr);
	int occ = 0;
	for (p=str; *(p+sublen-1) != '\0'; p++) {
		int matched = 1;
		/*for (int i = 0; i < sublen; i ++) {
			if (*(p+i) != *(q+i)) {
				matched = 0;
				break;
			}
		}*/
		if (strncmp (p,substr,sublen)!=0) matched = 0;
		if (matched == 1) occ++;
	}
	return occ;
}

int FindFirstAndInsert (char *str, char *substr, char *insert_str) {
	int insert_len = strlen(insert_str);
	char *ptr = strstr(str,substr);
	if (ptr == NULL) return 0;
	strcpy(ptr+insert_len, ptr);
	for (int i = 0; i < insert_len; i ++) {
		*(ptr+i) = insert_str[i];
	}
	//strcpy(ptr, insert_str);
	return 1;
}

int FindFirstAndDelete (char *str, char *substr) {
	int sublen = strlen(substr);
	char *ptr = strstr(str,substr);
	if (ptr == NULL) return 0;
	strcpy(ptr,ptr+sublen);
	return 1;
}
int FindFirstAndReplace (char *str, char *substr, char *replace_str) {
	char *ptr = strstr(str,substr);
	if (ptr == NULL) return 0;
	int sublen = strlen(substr);
	int replacelen = strlen(replace_str);
	strcpy(ptr+replacelen, ptr+sublen);
	for (int i = 0; i < replacelen; i ++) {
		*(ptr+i) = replace_str[i];
	}
	return 1;
}
