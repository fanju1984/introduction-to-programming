/*
 * pointer_string.h
 *
 *  Created on: 18 Dec 2017
 *      Author: fanj
 */

#ifndef POINTER_STRING_H_
#define POINTER_STRING_H_

#include<iostream>
using namespace std;

#include<string.h>

struct Query {
	int uid; // user ID
	char text[100]; // text of query
	int year; // year of query
	int month; // month of query
};

void ParseLine (char *line, struct Query *ptr);
void ParseUID (char *part, struct Query *ptr);
void ParseText (char *part, struct Query *ptr);
void ParseDate (char *part, struct Query *ptr);

int SubstrOccurNum(char *str, char *substr);

int FindFirstAndInsert (char *str, char *substr, char *insert_str);
int FindFirstAndDelete (char *str, char *substr);
int FindFirstAndReplace (char *str, char *substr, char *replace_str);


#endif /* POINTER_STRING_H_ */
