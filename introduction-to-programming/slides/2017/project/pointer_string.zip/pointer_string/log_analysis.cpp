/*
 * log_analysis.cpp
 *
 *  Created on: 17 Dec 2017
 *      Author: fanj
 */

#include<iostream>
#include<fstream>
using namespace std;

#include "pointer_string.h"
#include <stdio.h>

int main () {
	char *filename = "data/log_2.txt";
	ifstream logfile (filename);
	if (!logfile.is_open()) { // IF the file cannot be open
		cout << "[Error]: Cannot open file `" <<
				filename << "`." << endl;
		return 0;
	}
	int count = 0;
	while (!logfile.eof()) {
		char line[200];
		logfile.getline(line, 200);
		cout << "Debug: " << line << endl;
		Query query;
		ParseLine (line, &query);
		// Output the parsed query;
		cout << "Query #" << count << endl;
		cout << "UID: " << query.uid << endl;
		cout << "Year: " << query.year << endl;
		cout << "Month: " << query.month << endl;
		cout << "Text: " << query.text << endl;

		// Number of Substring occurrence
		char substr[10] = "flu";
		int occ = SubstrOccurNum(query.text, substr);
		cout << "Occurrence of `" << substr << "`: " << occ << endl;
		char *first_ptr = strstr(query.text,substr);
		if (first_ptr != NULL) cout << "Position of first occurrence: " <<
				(first_ptr-query.text) << endl;

		// Find first occurrence and Insert
		char *insert_str = "this ";
		FindFirstAndInsert (query.text, substr, insert_str);
		cout << "Find & Insert: " << query.text << endl;

		// Find first occurrence and Delete
		FindFirstAndDelete (query.text, substr);
		cout << "Find & Delete: " << query.text << endl;

		// Find first occurrence and Replace
		char *substr1 = "fuel";
		char *replace_str = "F";
		FindFirstAndReplace (query.text, substr1, replace_str);
		cout << "Find & Replace: " << query.text << endl;
		cout << endl;
		count ++;
	}
	logfile.close();
	return 0;
}
